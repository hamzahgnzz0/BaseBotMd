var img = {
  Register: [""]
}
var video = {
}

module.exports = { img }
require("../settings")
var ex = exports
module.ex = LangMess = {
  Register: ["Maaf, Anda Sudah Pernah Mendaftar Sebelumnya", "Anda sudah Pernah Mendaftar", "Anda Sudah Terdaftar", "Maaf, Anda Sudah Terdaftar Di Database Kami", "Command Ini Sudah Pernah Anda Jalankan Sebelumnya"],
  NotRegister: ["Maaf, Untuk Menggunakan Perintah Tersebut Anda Harus Mendaftar Terlebih Dahulu Ketik _Daftar_ Untuk Mendaftar", "Perintah Tersebut Hanya Dapat Digunakan Jika Anda Sudah Mendaftar Silahkan Mendaftar Terlebih Dahulu"],
  IsiSaldo: [""],
  AnimeWaifu: ["_Nih Waifunya, Dasar Wibu_"],
  Asupan: ["_Nih, Biar Semangat"],
  Admin: ["_Fitur Khusus Admin Group_"],
  BotNotAdmin: ["_Bot Bukan Admin, Jadikan Bot Sebagai Admin Terlebih Dahulu_"],
  Donasi: ["Terima Kasih Untuk Yang Sudah Berdonasi, Yang Gk Berdonasi Gkpp🗿"],
  Done: ["Berhasil"],
  EndLimit: ["_Limit Anda Sudah Habis. Silahkan Tunggu Sampai Besok Atau Beli Premium Untuk Unlimited Limit_"],
  Error: ["Maaf Fitur Eror", "Maaf Sedang Eror"],
  Group: ["_Fitur Khusus Dalam Group_"],
  JadiAnime: ["_Anjayy Wibu, Lari Ada Wibu_"],
  Limit: ["1 limit telah di gunakan"],
  Owner: ["_Fitur Khusus Owner Bot_", "Perintah Tersebut Hanya Dapat Digunakan Oleh Owner Bot, Silahkan Hubungi Owner Untuk Menjadi Owner Bot", "Anda Bukan Owner, Perintah Ini Hanya Untuk Owner"],
  OwnerCr: ["Itu Owner Saya Kak, Jangan Di Spam Ya!!"],
  Privhasil: ["_Hasilnya Sedang Di Kirim Di Chat Pribadi_"],
  Privat: ["_Maaf Fitur Ini Hanya Dapat Digunakan Di Private Chat_"],
  Searchimg: ["_Tunggu Sebentar, Sedang Mencari Foto_"],
  Searchjbw: ["_Tunggu Sebentar, Sedang Mencari Jawaban_"],
  Sendaudio: ["_Tunggu Sebentar, Sedang Memuat Audio_"],
  Sendvideo: ["_Tunggu Sebentar, Sedang Memuat Video_"],
  usrpanel: ["_Anda Sudah Pernah Mendaftar Sebelumnya_"],
  Wait: ["_Sedang di proses. Mohon Tunggu Sebentar_"]
}
  
ex.Daftar = (prefix, command, pushname, register, serialUser, sender) => {
 return `*MENDAFTAR KE DATABASE*
 *Terimakasih telah mendaftarkan diri ke database BOT berikut adalah infonya*
 
● *Nama : ${pushname}*
● *Nomor : ${sender.split('@')[0]}*
● *Pengguna : ${register.length}*
● *Email : ${email}*
● *SN : ${serialUser}*

 *Gunakan bot sewajarnya*`
}

ex.Donasi = (pushname) => {
 return `Silahkan BerDonasi ${pushname}
*Dana* : ${global.dana}
*Gopay* : ${global.gopay}
*LinkAja* : ${global.linkaja}
*Pulsa Im3* : ${global.pulsaim3}
*Pulsa Telkomsel* : ${global.pulsatsel}
*Pulsa Axis/Xl* : ${global.pulsaxl}
*Saweria* : ${global.saweria}`
}

ex.CekSaldo = (pushname, salam, mundur, jam, tanggal, runtime, sender, db, prefix, toRupiah, q, cekSaldo, db_saldo) => {
 return `*━━ CEK SALDO KAMU ━━*
 _• *Name:* ${pushname}_ 
 _• *Nomer:* ${sender.split('@')[0]}_ 
 _• *Saldo:* Rp${toRupiah(cekSaldo(sender, db_saldo))}_ 
 
 *Note :* 
 _Saldo hanya bisa digunakan untuk buysrv_ 
 _Tidak bisa ditarik dalam bentuk apapun_!
 _User dapat mentransfer saldonya ke user lain yang terdaftar di database kami_`
}

let q = "```"
ex.Menu = (pushname, salam, mundur, upload, OwnerName, NameBot, jam, tanggal, runtime, sender, db, prefix, toRupiah, q, cekSaldo, db_saldo) => {
  return `${salam.slice(0,1).toUpperCase() + salam.slice(1)} ${pushname}

*HITUNG MUNDUR IDUL ADHA*
 ${mundur}

╭✄┈┈┈⟬ *INFO-BOT* ⟭
┆❐ Creator : ${OwnerName}
┆❐ Nama Bot : ${NameBot}
┆❐ Waktu : ${jam}
┆❐ Hari : ${tanggal}
┆❐ Aktif Selama : ${runtime}
╰──────────◇
╭✄┈┈┈⟬ *INFO-USER* ⟭
┆❐ Nama : ${pushname}
┆❐ Nomor : ${sender.split('@')[0]}
┆❐ Saldo : Rp ${toRupiah(cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo))}
╰──────────◇

*TERIMA KASIH KEPADA* 
  ❐ Allah Swt
  ❐ Ibu
  ❐ Ayah
  ❐ Hads
  ❐ VinzDev
  ❐ Misel
  ❐ Fatih Arridho
  ❐ Ferdiz
  ❐ Zeeoneofc
  ❐ Jer Ofc
  ❐ Hamzah
  ❐ Semua Creator Bot

`
}
const p = "```"
const help = { menu(pushname, salam, mundur, upload, OwnerName, NameBot, jam, tanggal, runtime, sender, db, prefix, toRupiah, q, cekSaldo, db_saldo){
  return `${salam.slice(0,1).toUpperCase() + salam.slice(1)} ${pushname}

*HITUNG MUNDUR IDUL ADHA*
 ${mundur}

╭✄┈┈┈⟬ *INFO-BOT* ⟭
┆❐ Creator : ${OwnerName}
┆❐ Nama Bot : ${NameBot}
┆❐ Waktu : ${jam}
┆❐ Hari : ${tanggal}
┆❐ Aktif Selama : ${runtime}
╰──────────◇
╭✄┈┈┈⟬ *INFO-USER* ⟭
┆❐ Nama : ${pushname}
┆❐ Nomor : ${sender.split('@')[0]}
┆❐ Saldo : Rp ${toRupiah(cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo))}
╰──────────◇

*TERIMA KASIH KEPADA* 
  ❐ Allah Swt
  ❐ Ibu
  ❐ Ayah
  ❐ Hads
  ❐ VinzDev
  ❐ Misel
  ❐ Fatih Arridho
  ❐ Ferdiz
  ❐ Zeeoneofc
  ❐ Jer Ofc
  ❐ Hamzah
  ❐ Semua Creator Bot

`
}
}
module.exports = help